<style type="text/css" media="all">
    <?php echo of_get_option('journal_css_code');?>
</style>